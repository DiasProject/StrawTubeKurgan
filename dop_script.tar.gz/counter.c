#include "iostream"
#include "cmath"
#include "fstream"
using namespace std;

int main()
{
	ifstream input;
	ofstream output;
	ofstream outf;
	input.open("test.txt");
	output.open("test_out.txt");
	outf.open("test_repeat.txt");
	double straw, X, Y, Z;
	int count=0, line_number = 0;
	int sum_event=0, event; 
	int tmp=0;
	while(!input.eof()){
		input>>event>>straw;//>>X>>Y>>Z;
		line_number++;
			if(straw == tmp){outf<<"line_number:"<<line_number<<" "<<straw<<" "<<tmp<<endl;}
			tmp = straw;
		if(straw!=-1){
				cout<<"Event:"<<sum_event<<" Straw:"<<straw<<endl;//" X:"<<X<<" Y:"<<Y<<" Z:"<<Z<<endl;
			sum_event++;
		}else{
			count++;	
			cout<<sum_event<<" "<<straw<<endl;//" "<<X<<" "<<Y<<" "<<Z<<endl;
			if(sum_event<8){output<<"line number where event less 8: "<<line_number<<endl;}	
			sum_event=0;
		}
	}
	cout<<"count="<<count<<endl;
	input.close();
	output.close();
	outf.close();
	return 0;
}
