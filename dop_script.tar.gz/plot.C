void plot()
{

	gROOT->SetStyle("Plain");
	TTree *tree = new TTree("tree","treelibrated tree");
	Int_t sum = 0;
	// create a branch with event
	tree->Branch("event",&sum, "sum/I");
	// fill some events with random numbers
	Double_t a, b, c, d;
	Int_t counter, line_N;
	ifstream in_file("test.txt");
	Int_t i=0;
	while(!in_file.eof())
	{ 
		//in_file>>line_N>>counter>>a;//>>b>>c>>d;
		in_file>>counter>>a;//>>b>>c>>d;
		if(a!=-1){
			i++;
		}else if(a==-1){
			sum=i;
			//cout<<sum<<endl;	
			tree->Fill();
			sum=0;
			i=0;
		}
	}

   // now draw some tree variables
	TCanvas *c1 = new TCanvas();
	c1->cd(1);
	tree->Draw("sum");  //energy of det a
	tree->Write();
	in_file.close();
}
